import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import multer from "multer";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;

const TEXT_MODEL = process.env.GEMINI_TEXT_MODEL || "gemini-3.5-flash-lite";
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || "gemini-3.1-flash-lite-image";
const POLLINATIONS_IMAGE_MODEL = process.env.POLLINATIONS_IMAGE_MODEL || "zimage";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 18 * 1024 * 1024 }
});

app.use(express.json({ limit: "2mb" }));
app.use(express.static(__dirname, { index: "index.html" }));


function imageSizeForAspect(aspectRatio = "1:1") {
  const map = {
    "1:1": [1024, 1024],
    "16:9": [1365, 768],
    "9:16": [768, 1365],
    "4:3": [1024, 768],
    "3:4": [768, 1024]
  };
  const [width, height] = map[aspectRatio] || map["1:1"];
  return { width, height };
}

async function generateWithPollinations(prompt, aspectRatio) {
  const key = process.env.POLLINATIONS_API_KEY;
  if (!key) {
    const err = new Error("POLLINATIONS_API_KEY is not configured in Render.");
    err.status = 503;
    throw err;
  }

  const { width, height } = imageSizeForAspect(aspectRatio);
  const url =
    `https://gen.pollinations.ai/image/${encodeURIComponent(prompt)}` +
    `?model=${encodeURIComponent(POLLINATIONS_IMAGE_MODEL)}` +
    `&width=${width}&height=${height}&safe=true&seed=-1`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Bearer ${key}`,
      "Accept": "image/*",
      "User-Agent": "ZECAY-AI-V3/3.0"
    }
  });

  if (!response.ok) {
    const body = await response.text().catch(() => "");
    const err = new Error(`Free-credit image provider error ${response.status}${body ? `: ${body.slice(0, 300)}` : ""}`);
    err.status = response.status;
    throw err;
  }

  const mimeType = response.headers.get("content-type") || "image/jpeg";
  const buffer = Buffer.from(await response.arrayBuffer());

  return {
    image: buffer.toString("base64"),
    mimeType,
    model: POLLINATIONS_IMAGE_MODEL,
    provider: "pollinations"
  };
}

function getAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    const err = new Error("GEMINI_API_KEY is not configured in Render.");
    err.status = 500;
    throw err;
  }
  return new GoogleGenAI({ apiKey });
}


function decodeXml(text = "") {
  return text
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/<[^>]+>/g, "")
    .trim();
}

function extractTag(block, tag) {
  const match = block.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, "i"));
  return match ? decodeXml(match[1]) : "";
}

function parseGoogleNewsRss(xml) {
  const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].map(m => m[1]);
  return items.slice(0, 14).map(block => {
    const sourceMatch = block.match(/<source(?:\s+url="([^"]*)")?>([\s\S]*?)<\/source>/i);
    return {
      title: extractTag(block, "title"),
      link: extractTag(block, "link"),
      published: extractTag(block, "pubDate"),
      source: sourceMatch ? decodeXml(sourceMatch[2]) : "Web"
    };
  }).filter(x => x.title && x.link);
}

async function getLiveNews(query) {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-IN&gl=IN&ceid=IN:en`;
  const response = await fetch(url, {
    headers: { "User-Agent": "ZECAY-AI-V2/2.1" }
  });
  if (!response.ok) throw new Error(`Live news feed returned ${response.status}`);
  return parseGoogleNewsRss(await response.text());
}

const SYSTEM_INSTRUCTION = `
You are ZECAY AI, a clear, practical and careful AI assistant.
The user may write English, Telugu, or Telugu in English letters. Reply in the same style unless asked otherwise.
For stocks, mutual funds, taxation, insurance, trading and personal finance, explain educationally, separate facts from opinions, never invent live data, avoid personalized Buy/Sell/Hold instructions, and mention market risk when relevant.
When an image, audio clip, PDF or text file is supplied, base your answer on that supplied content. If unclear, say what is missing instead of guessing.
`;

function safeHistory(historyText) {
  if (!historyText) return "";
  try {
    const history = JSON.parse(historyText);
    if (!Array.isArray(history)) return "";
    return history.slice(-12)
      .map(m => `${m.role === "assistant" ? "ZECAY AI" : "User"}: ${String(m.content || "").slice(0, 4000)}`)
      .join("\n");
  } catch { return ""; }
}

function buildInput(message, file, historyText) {
  const context = safeHistory(historyText);
  const basePrompt = [
    context ? `Recent conversation:\n${context}` : "",
    message ? `Current user request:\n${message}` : "Please understand the attached content and respond helpfully."
  ].filter(Boolean).join("\n\n");

  if (!file) return basePrompt;

  const mime = (file.mimetype || "application/octet-stream").toLowerCase();
  const data = file.buffer.toString("base64");

  if (mime.startsWith("image/")) {
    return [{ type: "text", text: basePrompt }, { type: "image", data, mime_type: mime }];
  }

  if (mime.startsWith("audio/")) {
    return [
      { type: "text", text: `${basePrompt}\n\nListen to the attached audio carefully. Understand the user's spoken request and answer it directly.` },
      { type: "audio", data, mime_type: mime }
    ];
  }

  if (mime === "application/pdf") {
    return [{ type: "text", text: basePrompt }, { type: "document", data, mime_type: "application/pdf" }];
  }

  const textLike = mime.startsWith("text/") || ["application/json","application/xml","text/csv"].includes(mime);
  if (textLike) {
    const text = file.buffer.toString("utf8").slice(0, 600000);
    return `${basePrompt}\n\nAttached file (${file.originalname}):\n${text}`;
  }

  const err = new Error("This file type is not supported yet. Upload an image, audio file, PDF, TXT, CSV, JSON or Markdown file.");
  err.status = 400;
  throw err;
}

app.post("/api/chat", upload.single("file"), async (req, res) => {
  try {
    const ai = getAI();
    const message = String(req.body?.message || "").trim();
    if (!message && !req.file) return res.status(400).json({ error: "Please type a message or attach a file." });

    const interaction = await ai.interactions.create({
      model: TEXT_MODEL,
      input: buildInput(message, req.file, req.body?.history),
      system_instruction: SYSTEM_INSTRUCTION,
      store: false
    });

    const answer = String(interaction.output_text || "").trim();
    res.json({ answer: answer || "I could not generate a text response.", model: TEXT_MODEL });
  } catch (error) {
    console.error("CHAT ERROR:", error);
    res.status(error?.status || 500).json({ error: error?.message || "Something went wrong while contacting Gemini." });
  }
});


app.post("/api/live-update", async (req, res) => {
  try {
    const query = String(req.body?.query || "").trim();
    if (!query) return res.status(400).json({ error: "Enter a topic for live updates." });

    const items = await getLiveNews(query);
    if (!items.length) {
      return res.status(404).json({ error: "No fresh public news results were found for this topic." });
    }

    const ai = getAI();
    const sourceText = items.map((x, i) =>
      `${i + 1}. ${x.title}\nSource: ${x.source}\nPublished: ${x.published}\nLink: ${x.link}`
    ).join("\n\n");

    const interaction = await ai.interactions.create({
      model: TEXT_MODEL,
      input: `Give a concise and useful LIVE UPDATE for: ${query}

Use ONLY the fresh source list below. Compare multiple publishers, mention uncertainty or conflicting reports, and do not invent facts.
For finance/markets, do not give personalized Buy/Sell/Hold advice.

FRESH SOURCES:
${sourceText}`,
      system_instruction: SYSTEM_INSTRUCTION,
      store: false
    });

    return res.json({
      answer: String(interaction.output_text || "").trim() || "Fresh sources found.",
      sources: items.slice(0, 10),
      fetchedAt: new Date().toISOString(),
      mode: "free-live-news"
    });
  } catch (error) {
    console.error("LIVE UPDATE ERROR:", error);
    return res.status(error?.status || 500).json({
      error: error?.message || "Could not fetch live updates right now."
    });
  }
});

app.post("/api/generate-image", async (req, res) => {
  const prompt = String(req.body?.prompt || "").trim();
  const aspectRatio = String(req.body?.aspectRatio || "1:1");

  if (!prompt) return res.status(400).json({ error: "Enter an image prompt." });

  try {
    const result = await generateWithPollinations(prompt, aspectRatio);
    return res.json(result);
  } catch (pollinationsError) {
    console.error("POLLINATIONS IMAGE ERROR:", pollinationsError);

    if (process.env.IMAGE_FALLBACK_GEMINI === "true") {
      try {
        const ai = getAI();
        const interaction = await ai.interactions.create({
          model: IMAGE_MODEL,
          input: prompt,
          response_format: { type: "image", aspect_ratio: aspectRatio, image_size: "1K" },
          store: false
        });

        const image = interaction.output_image;
        if (!image?.data) throw new Error("Gemini did not return an image.");

        return res.json({
          image: image.data,
          mimeType: image.mime_type || "image/png",
          model: IMAGE_MODEL,
          provider: "gemini"
        });
      } catch (geminiError) {
        console.error("GEMINI IMAGE FALLBACK ERROR:", geminiError);
      }
    }

    let message = pollinationsError?.message || "Image generation failed.";
    if (/401|403|402|key|credit|budget|quota|balance/i.test(message)) {
      message =
        "Image generation needs a valid Pollinations API key with available free credits/budget. Add POLLINATIONS_API_KEY in Render Environment Variables.";
    }

    return res.status(pollinationsError?.status || 500).json({ error: message });
  }
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, app: "ZECAY AI V3", textModel: TEXT_MODEL, imageProvider: "pollinations", imageModel: POLLINATIONS_IMAGE_MODEL, geminiConfigured: Boolean(process.env.GEMINI_API_KEY), pollinationsConfigured: Boolean(process.env.POLLINATIONS_API_KEY) });
});

app.get("/", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.get("/{*splat}", (req, res) => res.sendFile(path.join(__dirname, "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`ZECAY AI V3 running on port ${PORT}`);
});
