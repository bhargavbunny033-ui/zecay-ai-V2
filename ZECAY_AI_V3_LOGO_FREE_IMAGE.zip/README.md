# ZECAY AI V3

Included:
- Your ZECAY gold logo in header, sidebar/welcome area, favicon and PWA icons
- Gemini chat with current JS SDK 2.x
- Voice recording
- Image / PDF / text file analysis
- Live Updates with source links
- Dark mode
- Telugu / English / Telugu-English
- SIP / Lumpsum / EMI calculators
- Chat history
- Read aloud
- PDF/Print export
- Image generation using Pollinations image API
- Generated-image download button

Required Render environment variables:
GEMINI_API_KEY = your Gemini key
POLLINATIONS_API_KEY = your Pollinations key

Optional:
POLLINATIONS_IMAGE_MODEL = zimage
IMAGE_FALLBACK_GEMINI = false

When uploaded as ZIP, use:
Build Command:
rm -rf app && mkdir app && unzip -q ZECAY_AI_V3_LOGO_FREE_IMAGE.zip -d app && cd app && rm -rf node_modules package-lock.json && npm install

Start Command:
cd app && npm start
