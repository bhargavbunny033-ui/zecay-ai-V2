const $ = (id) => document.getElementById(id);
const chat = $("chat");
const welcome = $("welcome");
const composer = $("composer");
const messageInput = $("messageInput");
const fileInput = $("fileInput");
const attachBtn = $("attachBtn");
const recordBtn = $("recordBtn");
const sendBtn = $("sendBtn");
const attachmentPreview = $("attachmentPreview");
const sidebar = $("sidebar");

let messages = [];
let selectedFile = null;
let mediaRecorder = null;
let audioChunks = [];
let activeCalc = "sip";

const STORAGE = {
  history: "zecay_v2_history",
  theme: "zecay_v2_theme",
  profile: "zecay_v2_profile",
  notices: "zecay_v2_notices"
};

function toast(text) {
  const el = $("toast");
  el.textContent = text;
  el.classList.remove("hidden");
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.add("hidden"), 2800);
}

function addNotice(text) {
  const list = JSON.parse(localStorage.getItem(STORAGE.notices) || "[]");
  list.unshift({ text, time: new Date().toLocaleString() });
  localStorage.setItem(STORAGE.notices, JSON.stringify(list.slice(0, 40)));
}

function saveCurrentChat() {
  if (!messages.length) return;
  const all = JSON.parse(localStorage.getItem(STORAGE.history) || "[]");
  const current = {
    id: Date.now(),
    title: (messages.find(m => m.role === "user")?.content || "New Chat").slice(0, 60),
    time: new Date().toLocaleString(),
    messages: JSON.parse(JSON.stringify(messages))
  };
  all.unshift(current);
  localStorage.setItem(STORAGE.history, JSON.stringify(all.slice(0, 30)));
}

function renderMessage(role, text, extra = {}) {
  welcome.style.display = "none";
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  if (role === "user") {
    avatar.textContent = "You";
  } else {
    const aiLogo = document.createElement("img");
    aiLogo.src = "/zecay-logo.png";
    aiLogo.alt = "ZECAY";
    aiLogo.style.width = "30px";
    aiLogo.style.height = "30px";
    aiLogo.style.objectFit = "contain";
    avatar.appendChild(aiLogo);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  if (extra.fileName) {
    const chip = document.createElement("div");
    chip.className = "attachment-chip";
    chip.textContent = `📎 ${extra.fileName}`;
    bubble.appendChild(chip);
  }
  if (extra.imageData) {
    const img = document.createElement("img");
    img.className = "generated-image";
    img.src = extra.imageData;
    bubble.appendChild(img);
  }
  row.append(avatar, bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
  return row;
}

function newChat() {
  saveCurrentChat();
  messages = [];
  selectedFile = null;
  attachmentPreview.classList.add("hidden");
  chat.innerHTML = "";
  chat.appendChild(welcome);
  welcome.style.display = "";
  messageInput.value = "";
  sidebar.classList.remove("open");
}

$("newChatBtn").addEventListener("click", newChat);
$("menuBtn").addEventListener("click", () => sidebar.classList.toggle("open"));
$("profileTopBtn").addEventListener("click", openProfile);

document.querySelectorAll("[data-prompt]").forEach(btn => {
  btn.addEventListener("click", () => {
    messageInput.value = btn.dataset.prompt;
    messageInput.focus();
  });
});

document.querySelectorAll("[data-action]").forEach(btn => {
  btn.addEventListener("click", () => handleAction(btn.dataset.action));
});

function handleAction(action) {
  sidebar.classList.remove("open");
  if (action === "live") {
    $("liveDialog").showModal();
  } else if (action === "stocks") {
    messageInput.value = "Explain the stock/company I name next with business, fundamentals, risks and what to verify. Do not give Buy/Sell/Hold.";
    messageInput.focus();
  } else if (action === "mutualfunds") {
    messageInput.value = "Help me understand a mutual fund or category in simple terms, including risk, suitability and what to compare.";
    messageInput.focus();
  } else if (action === "learn") {
    messageInput.value = "Teach me one useful finance concept with a simple example.";
    messageInput.focus();
  } else if (action === "calculator") {
    $("calculatorDialog").showModal();
  } else if (action === "imagegen") {
    $("imageDialog").showModal();
  } else if (action === "history") {
    showHistory();
  } else if (action === "profile") {
    openProfile();
  } else if (action === "notifications") {
    showNotifications();
  }
}

attachBtn.addEventListener("click", () => fileInput.click());
$("quickUpload").addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", () => {
  selectedFile = fileInput.files?.[0] || null;
  if (!selectedFile) return;
  attachmentPreview.classList.remove("hidden");
  attachmentPreview.innerHTML = `<span>📎 ${escapeHtml(selectedFile.name)} (${formatBytes(selectedFile.size)})</span><button type="button" id="removeAttachment" class="icon">✕</button>`;
  $("removeAttachment").onclick = clearAttachment;
});

function clearAttachment() {
  selectedFile = null;
  fileInput.value = "";
  attachmentPreview.classList.add("hidden");
  attachmentPreview.innerHTML = "";
}

messageInput.addEventListener("input", () => {
  messageInput.style.height = "auto";
  messageInput.style.height = Math.min(messageInput.scrollHeight, 150) + "px";
});

composer.addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = messageInput.value.trim();
  if (!message && !selectedFile) return;

  const lang = $("languageSelect").value;
  const langInstruction =
    lang === "english" ? "Reply in English." :
    lang === "telugu" ? "తెలుగులో సమాధానం ఇవ్వండి." :
    lang === "tenglish" ? "Reply in Telugu using English letters." : "";

  const userText = message || "Analyze this attachment.";
  renderMessage("user", userText, { fileName: selectedFile?.name });
  messages.push({ role: "user", content: userText });

  const form = new FormData();
  form.append("message", `${message}\n${langInstruction}`.trim());
  form.append("history", JSON.stringify(messages.slice(0, -1)));
  if (selectedFile) form.append("file", selectedFile);

  messageInput.value = "";
  messageInput.style.height = "auto";
  clearAttachment();
  sendBtn.disabled = true;

  const thinking = renderMessage("assistant", "Thinking…");

  try {
    const r = await fetch("/api/chat", { method: "POST", body: form });
    const data = await r.json();
    thinking.remove();
    if (!r.ok) throw new Error(data.error || "Request failed");
    renderMessage("assistant", data.answer);
    messages.push({ role: "assistant", content: data.answer });
    addNotice("New AI answer generated");
  } catch (err) {
    thinking.remove();
    renderMessage("assistant", "⚠️ " + err.message);
  } finally {
    sendBtn.disabled = false;
    messageInput.focus();
  }
});

recordBtn.addEventListener("click", async () => {
  if (mediaRecorder?.state === "recording") {
    mediaRecorder.stop();
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = e => e.data.size && audioChunks.push(e.data);
    mediaRecorder.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType || "audio/webm" });
      selectedFile = new File([blob], `voice-${Date.now()}.webm`, { type: blob.type || "audio/webm" });
      attachmentPreview.classList.remove("hidden");
      attachmentPreview.innerHTML = `<span>🎙️ Voice recording ready (${formatBytes(selectedFile.size)})</span><button type="button" id="removeAttachment" class="icon">✕</button>`;
      $("removeAttachment").onclick = clearAttachment;
      recordBtn.classList.remove("recording");
      recordBtn.textContent = "🎙️";
      if (!messageInput.value.trim()) messageInput.value = "Please understand my voice question and answer it.";
      toast("Voice recording attached. Tap Send.");
    };
    mediaRecorder.start();
    recordBtn.classList.add("recording");
    recordBtn.textContent = "⏹️";
    toast("Recording… tap again to stop");
  } catch {
    toast("Microphone permission is required.");
  }
});

$("readLastBtn").addEventListener("click", () => {
  const last = [...messages].reverse().find(m => m.role === "assistant");
  if (!last) return toast("No AI answer yet.");
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(last.content);
  u.lang = detectTelugu(last.content) ? "te-IN" : "en-IN";
  speechSynthesis.speak(u);
});

$("exportPdfBtn").addEventListener("click", () => {
  if (!messages.length) return toast("No chat to export.");
  window.print();
});

$("themeBtn").addEventListener("click", () => {
  const dark = !document.body.classList.contains("dark");
  document.body.classList.toggle("dark", dark);
  localStorage.setItem(STORAGE.theme, dark ? "dark" : "light");
  $("themeBtn").textContent = dark ? "☀️" : "🌙";
});
if (localStorage.getItem(STORAGE.theme) === "dark") {
  document.body.classList.add("dark");
  $("themeBtn").textContent = "☀️";
}


$("getLiveBtn").addEventListener("click", async () => {
  const query = $("liveQuery").value.trim();
  if (!query) return toast("Enter a topic.");
  const box = $("liveResult");
  box.innerHTML = "<p>Searching fresh sources…</p>";
  $("getLiveBtn").disabled = true;

  try {
    const r = await fetch("/api/live-update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Live update failed");

    box.innerHTML = "";

    const summary = document.createElement("div");
    summary.className = "result-card";
    summary.textContent = data.answer;
    box.appendChild(summary);

    const heading = document.createElement("h3");
    heading.textContent = "Sources";
    box.appendChild(heading);

    (data.sources || []).forEach((s, i) => {
      const a = document.createElement("a");
      a.className = "source-card";
      a.href = s.link;
      a.target = "_blank";
      a.rel = "noopener";
      a.innerHTML = `<b>${i + 1}. ${escapeHtml(s.source || "Source")}</b><span>${escapeHtml(s.title)}</span><small>${escapeHtml(s.published || "")}</small>`;
      box.appendChild(a);
    });

    const add = document.createElement("button");
    add.type = "button";
    add.className = "primary";
    add.textContent = "Add Summary to Chat";
    add.onclick = () => {
      renderMessage("assistant", `LIVE UPDATE — ${query}\n\n${data.answer}`);
      messages.push({ role: "assistant", content: `LIVE UPDATE — ${query}\n\n${data.answer}` });
      $("liveDialog").close();
    };
    box.appendChild(add);
    addNotice(`Live update checked: ${query}`);
  } catch (e) {
    box.innerHTML = `<div class="result-card">⚠️ ${escapeHtml(e.message)}</div>`;
  } finally {
    $("getLiveBtn").disabled = false;
  }
});

$("generateImageBtn").addEventListener("click", async () => {
  const prompt = $("imagePrompt").value.trim();
  if (!prompt) return toast("Enter an image prompt.");
  const box = $("imageResult");
  box.textContent = "Generating image…";
  $("generateImageBtn").disabled = true;
  try {
    const r = await fetch("/api/generate-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, aspectRatio: $("aspectRatio").value })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Image generation failed");
    const src = `data:${data.mimeType};base64,${data.image}`;
    box.innerHTML = "";
    const img = document.createElement("img");
    img.src = src;
    box.appendChild(img);

    const download = document.createElement("a");
    download.className = "download-image-btn";
    download.href = src;
    download.download = `ZECAY_AI_${Date.now()}.png`;
    download.textContent = "⬇️ Download Image";
    box.appendChild(download);

    const add = document.createElement("button");
    add.type = "button";
    add.className = "primary";
    add.textContent = "Add to Chat";
    add.onclick = () => {
      renderMessage("assistant", `Generated image: ${prompt}`, { imageData: src });
      messages.push({ role: "assistant", content: `[Generated image] ${prompt}` });
      $("imageDialog").close();
    };
    box.appendChild(add);
    addNotice("Image generated");
  } catch (e) {
    box.textContent = "⚠️ " + e.message;
  } finally {
    $("generateImageBtn").disabled = false;
  }
});

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    activeCalc = tab.dataset.calc;
    $("amountLabel").childNodes[0].nodeValue =
      activeCalc === "sip" ? "Monthly Amount ₹" :
      activeCalc === "lumpsum" ? "Investment Amount ₹" : "Loan Amount ₹";
  });
});

$("calculateBtn").addEventListener("click", () => {
  const P = Number($("calcAmount").value || 0);
  const annual = Number($("calcRate").value || 0);
  const years = Number($("calcYears").value || 0);
  if (P <= 0 || annual < 0 || years <= 0) return toast("Enter valid values.");

  let html = "";
  if (activeCalc === "sip") {
    const r = annual / 1200;
    const n = years * 12;
    const fv = r === 0 ? P*n : P * (((1+r)**n - 1) / r) * (1+r);
    html = `<b>Estimated Value:</b> ${money(fv)}<br><b>Invested:</b> ${money(P*n)}<br><b>Estimated Gain:</b> ${money(fv-P*n)}`;
  } else if (activeCalc === "lumpsum") {
    const fv = P * (1 + annual/100) ** years;
    html = `<b>Estimated Value:</b> ${money(fv)}<br><b>Investment:</b> ${money(P)}<br><b>Estimated Gain:</b> ${money(fv-P)}`;
  } else {
    const r = annual / 1200;
    const n = years * 12;
    const emi = r === 0 ? P/n : P*r*(1+r)**n / ((1+r)**n - 1);
    html = `<b>Monthly EMI:</b> ${money(emi)}<br><b>Total Payment:</b> ${money(emi*n)}<br><b>Total Interest:</b> ${money(emi*n-P)}`;
  }
  $("calcResult").innerHTML = html + `<br><small>Illustrative calculation only.</small>`;
});

function showHistory() {
  const all = JSON.parse(localStorage.getItem(STORAGE.history) || "[]");
  const list = $("historyList");
  list.innerHTML = all.length ? "" : "<p>No saved history yet.</p>";
  all.forEach(item => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.innerHTML = `<b>${escapeHtml(item.title)}</b><br><small>${escapeHtml(item.time)}</small>`;
    div.onclick = () => {
      saveCurrentChat();
      messages = item.messages || [];
      chat.innerHTML = "";
      messages.forEach(m => renderMessage(m.role, m.content));
      $("historyDialog").close();
    };
    list.appendChild(div);
  });
  $("historyDialog").showModal();
}
$("clearHistoryBtn").addEventListener("click", () => {
  localStorage.removeItem(STORAGE.history);
  $("historyList").innerHTML = "<p>No saved history yet.</p>";
});

function openProfile() {
  const p = JSON.parse(localStorage.getItem(STORAGE.profile) || "{}");
  $("profileName").value = p.name || "";
  $("profileLanguage").value = p.language || $("languageSelect").value;
  $("profileDialog").showModal();
}
$("saveProfileBtn").addEventListener("click", () => {
  const p = { name: $("profileName").value.trim(), language: $("profileLanguage").value };
  localStorage.setItem(STORAGE.profile, JSON.stringify(p));
  $("languageSelect").value = p.language;
  $("profileTopBtn").textContent = (p.name || "GK").slice(0,2).toUpperCase();
  $("profileDialog").close();
  toast("Profile saved on this device.");
});
{
  const p = JSON.parse(localStorage.getItem(STORAGE.profile) || "{}");
  if (p.language) $("languageSelect").value = p.language;
  if (p.name) $("profileTopBtn").textContent = p.name.slice(0,2).toUpperCase();
}

function showNotifications() {
  const items = JSON.parse(localStorage.getItem(STORAGE.notices) || "[]");
  $("notificationList").innerHTML = items.length ? "" : "<p>No notifications yet.</p>";
  items.forEach(n => {
    const div = document.createElement("div");
    div.className = "notice-item";
    div.innerHTML = `${escapeHtml(n.text)}<br><small>${escapeHtml(n.time)}</small>`;
    $("notificationList").appendChild(div);
  });
  $("notificationsDialog").showModal();
}

function detectTelugu(text){ return /[\u0C00-\u0C7F]/.test(text); }
function formatBytes(bytes){ return bytes < 1024*1024 ? `${(bytes/1024).toFixed(1)} KB` : `${(bytes/1024/1024).toFixed(1)} MB`; }
function money(n){ return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n); }
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

window.addEventListener("beforeunload", saveCurrentChat);
