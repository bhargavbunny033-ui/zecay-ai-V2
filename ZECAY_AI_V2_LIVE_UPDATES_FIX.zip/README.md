# ZECAY AI V2

Features:
- Live Updates from multiple fresh public news publishers with source links
- Gemini text chat
- Voice recording upload and AI understanding
- Image upload and analysis
- PDF / TXT / CSV / JSON / Markdown analysis
- AI image generation option
- Read-aloud
- Chat history (stored on the device)
- Dark mode
- Telugu / English / Telugu-English
- SIP / Lumpsum / EMI calculators
- Stocks and Mutual Funds shortcuts
- Export chat through Print / Save as PDF
- Local profile
- In-app activity notifications

Render:
Build Command: npm install
Start Command: npm start

Environment variable:
GEMINI_API_KEY = your Gemini key

Optional:
GEMINI_TEXT_MODEL = gemini-3.1-flash-lite
GEMINI_IMAGE_MODEL = gemini-3.1-flash-lite-image

Live Updates free mode uses public news RSS search and does not require an extra search API key.


ROOT ROUTE FIX: explicit / route + Express 5 catch-all added for Render.
